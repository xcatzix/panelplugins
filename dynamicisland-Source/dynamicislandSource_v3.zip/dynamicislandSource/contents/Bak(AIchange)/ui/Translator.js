// Translator.js - minimal i18n stub
.pragma library
var tr = function(ctx, text) { return text; }
var tr = function(text) { return text; }
var t = function(text) { return text; }
