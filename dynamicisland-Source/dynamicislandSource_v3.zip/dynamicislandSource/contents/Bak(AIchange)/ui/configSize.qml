import QtQuick
import QtQuick.Controls as QQC2
import org.kde.kirigami as Kirigami
import "Translator.js" as Tr

Kirigami.FormLayout {
    property alias cfg_expandedWidth: widthSpin.value
    property alias cfg_expandedHeight: heightSpin.value
    property alias cfg_cornerRadius: radiusSpin.value

    QQC2.SpinBox { id: widthSpin;  Kirigami.FormData.label: Tr.t("Panel width:");        from: 240; to: 600; stepSize: 10 }
    QQC2.SpinBox { id: heightSpin;  Kirigami.FormData.label: Tr.t("Panel height:");       from: 64;  to: 160; stepSize: 2 }
    QQC2.SpinBox { id: radiusSpin;  Kirigami.FormData.label: Tr.t("Corner radius:");      from: 6;   to: 28;  stepSize: 1 }
}
