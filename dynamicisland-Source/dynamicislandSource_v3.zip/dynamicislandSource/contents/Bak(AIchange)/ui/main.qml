import QtQuick
import QtQuick.Layouts
import org.kde.kirigami as Kirigami
import org.kde.notificationmanager as NotificationManager
import org.kde.plasma.core as PlasmaCore
import org.kde.plasma.components as PlasmaComponents
import org.kde.plasma.plasmoid
import org.kde.plasma.workspace.components as WorkspaceComponents
import "Translator.js" as Tr

PlasmoidItem {
    id: root

    Plasmoid.backgroundHints: PlasmaCore.Types.NoBackground

    // Native hover tooltip
    toolTipMainText: {
        if (popupOpen) return ""
        if (compactTitle.length > 0) return compactTitle
        return timeText
    }
    toolTipSubText: {
        if (popupOpen) return ""
        return ""
    }

    readonly property int compactMinWidth: 82
    readonly property int compactMaxWidth: 1200
    readonly property int compactSidePadding: 18
    readonly property int compactTextMaxWidth: 420
    readonly property int compactTextWidth: Math.min(compactTextMaxWidth, Math.ceil(compactTitleMetrics.width))
    readonly property int compactLeadingWidth: showGreenDot ? 10 : 24
    readonly property int compactTrailingWidth: Math.ceil(compactTimeMetrics.width) + (showFps ? 48 : 0) + (showCpuStat ? 60 : 0) + (showRamStat ? 60 : 0) + (showTempStat && cpuTemp > 0 ? 50 : 0)
    readonly property int compactGapWidth: 16
    readonly property int compactSeparatorsWidth: moduleSeparators ? Math.max(0, compactVisibleList.length - 1) * 16 : 0
    readonly property int compactContentWidth: compactLeadingWidth + compactTextWidth + compactTrailingWidth + compactGapWidth + compactSeparatorsWidth
    readonly property int compactWidth: Math.max(compactMinWidth, Math.min(compactMaxWidth, compactContentWidth + compactSidePadding * 2))
    readonly property int expandedWidth: Plasmoid.configuration.expandedWidth
    readonly property int compactHeight: 32
    readonly property int expandedHeight: Plasmoid.configuration.expandedHeight
    readonly property bool animationsEnabled: Plasmoid.configuration.animationsEnabled
    readonly property real animMultiplier: 100 / Math.max(40, Plasmoid.configuration.animationSpeed)
    readonly property string accent: Plasmoid.configuration.accentColor
    readonly property int cornerRadius: Plasmoid.configuration.cornerRadius
    readonly property bool backgroundEnabled: Plasmoid.configuration.backgroundEnabled
    readonly property bool borderEnabled: Plasmoid.configuration.borderEnabled
    readonly property bool followTheme: Plasmoid.configuration.followSystemTheme
    readonly property color panelBackground: !backgroundEnabled ? "transparent"
        : withAlpha(followTheme ? Kirigami.Theme.backgroundColor : Plasmoid.configuration.backgroundColor, Plasmoid.configuration.backgroundOpacity)
    readonly property color borderColor: (borderEnabled && backgroundEnabled)
        ? (followTheme ? withAlpha(Kirigami.Theme.textColor, 16) : Qt.rgba(1, 1, 1, 0.16))
        : Qt.rgba(0, 0, 0, 0)
    readonly property color textPrimary: followTheme ? Kirigami.Theme.textColor : "white"
    readonly property color textSecondary: followTheme
        ? withAlpha(Kirigami.Theme.textColor, 75)
        : Qt.rgba(1, 1, 1, 0.74)
    readonly property string idleDotColor: Plasmoid.configuration.idleDotColor
    readonly property string sharingDotColor: Plasmoid.configuration.sharingDotColor
    readonly property string timeText: {
        let fmt = Plasmoid.configuration.use24HourClock ? "HH:mm" : "h:mm"
        if (Plasmoid.configuration.showSeconds) {
            fmt += ":ss"
        }
        if (!Plasmoid.configuration.use24HourClock) {
            fmt += " AP"
        }
        let out = Qt.formatTime(currentTime, fmt)
        if (Plasmoid.configuration.showDate) {
            out = Qt.formatDate(currentTime, "ddd d") + "  " + out
        }
        return out
    }
    readonly property bool eventActive: eventTimer.running || notificationPulse.running

    readonly property bool enableNotifications: Plasmoid.configuration.enableNotifications
    readonly property bool enableDownloads: Plasmoid.configuration.enableDownloads
    readonly property bool enableScreenSharing: Plasmoid.configuration.enableScreenSharing
    readonly property bool enableSysMonitor: Plasmoid.configuration.enableSysMonitor
    readonly property bool showFps: Plasmoid.configuration.showFps
    readonly property string fpsStyle: Plasmoid.configuration.fpsStyle

    // System monitor properties
    readonly property real cpuUsage: sysLoader.item ? sysLoader.item.cpuUsage : 0
    readonly property real ramUsage: sysLoader.item ? sysLoader.item.ramUsage : 0
    readonly property real cpuTemp: sysLoader.item ? sysLoader.item.cpuTemp : 0
    readonly property bool showCpuStat: Plasmoid.configuration.showCpuStat
    readonly property bool showRamStat: Plasmoid.configuration.showRamStat
    readonly property bool showTempStat: Plasmoid.configuration.showTempStat
    readonly property string statsText: {
        let parts = []
        if (showCpuStat) parts.push("CPU " + Math.round(cpuUsage) + "%")
        if (showRamStat) parts.push("RAM " + Math.round(ramUsage) + "%")
        if (showTempStat && cpuTemp > 0) parts.push(Math.round(cpuTemp) + "°C")
        return parts.join("  ")
    }

    // All modules shown in a row: time, cpu, ram, temp, fps, notifications
    readonly property var compactVisibleList: {
        let out = []
        out.push("time")
        if (showCpuStat) out.push("cpu")
        if (showRamStat) out.push("ram")
        if (showTempStat && cpuTemp > 0) out.push("temp")
        if (showFps) out.push("fps")
        if (hasNotification) out.push("notification")
        return out
    }

    readonly property bool moduleSeparators: Plasmoid.configuration.moduleSeparators

    readonly property int fps: fpsMeter.smoothFrameTime > 0 ? Math.round(1 / fpsMeter.smoothFrameTime) : 0

    readonly property bool hasNotification: enableNotifications && (notificationPulse.running || unreadCount > 0)
    readonly property bool hasJobs: enableDownloads && jobsCount > 0
    readonly property bool idleMode: !eventTimer.running && !hasNotification && !buildTimer.running && !hasJobs
    readonly property bool showGreenDot: idleMode

    readonly property string compactTitle: {
        if (showGreenDot) {
            return ""
        }
        if (hasNotification) {
            return notificationTitle || Tr.t("Notification")
        }
        if (hasJobs) {
            return jobsCount > 0 ? Tr.t("Download active") : Tr.t("Downloads")
        }
        return ""
    }

    property bool popupOpen: false
    property int unreadCount: 0
    property int jobsCount: 0
    property int jobsPercent: 0
    property date currentTime: new Date()
    property string notificationTitle: ""
    property string notificationBody: ""
    property string notificationIcon: "notifications"
    property string notificationApp: ""
    property var notificationActionNames: []
    property var notificationActionLabels: []
    property bool notificationHasDefaultAction: false

    Layout.minimumWidth: compactWidth
    Layout.minimumHeight: compactHeight
    Layout.preferredWidth: compactWidth
    Layout.preferredHeight: compactHeight
    Layout.maximumWidth: compactWidth
    Layout.maximumHeight: compactHeight

    implicitWidth: Layout.preferredWidth
    implicitHeight: Layout.preferredHeight

    TextMetrics {
        id: compactTitleMetrics
        text: root.compactTitle
        font.pointSize: 12
        font.weight: Font.Medium
    }

    TextMetrics {
        id: compactTimeMetrics
        text: root.timeText
        font.pointSize: 16
        font.weight: Font.Medium
    }

    // System monitor loader
    Loader {
        id: sysLoader
        active: root.enableSysMonitor
        source: "SystemMonitor.qml"
    }

    FrameAnimation {
        id: fpsMeter
        running: root.showFps
    }

    Timer {
        interval: 1000
        running: true
        repeat: true
        onTriggered: {
            root.currentTime = new Date()
        }
    }

    Timer {
        id: eventTimer
        interval: 3000
    }

    Timer {
        id: notificationPulse
        interval: 15000
    }

    Timer {
        id: buildTimer
        interval: 6000
    }

    function dur(ms) {
        return animationsEnabled ? Math.round(ms * animMultiplier) : 0
    }

    function withAlpha(hex, percent) {
        const c = Qt.lighter(hex, 1.0)
        return Qt.rgba(c.r, c.g, c.b, Math.max(0, Math.min(100, percent)) / 100)
    }

    function setNotification(roleModel) {
        notificationTitle = roleModel.summary || roleModel.applicationName || Tr.t("Notification")
        notificationBody = roleModel.body || roleModel.text || ""
        notificationApp = roleModel.applicationName || ""
        notificationIcon = roleModel.applicationIconName || roleModel.iconName || "notifications"
        if (notificationIcon.length === 0) {
            notificationIcon = "notifications"
        }
        notificationActionNames = roleModel.actionNames || []
        notificationActionLabels = roleModel.actionLabels || []
        notificationHasDefaultAction = roleModel.hasDefaultAction || false
    }

    function dismissNotification() {
        if (unreadCount > 0) {
            notificationsModel.close(notificationsModel.index(0, 0))
        }
        notificationPulse.stop()
    }

    function activateNotification() {
        if (notificationHasDefaultAction) {
            notificationsModel.invokeDefaultAction(notificationsModel.index(0, 0))
        }
        closePopup()
    }

    function invokeNotificationAction(i) {
        const names = notificationActionNames
        if (i < 0 || i >= names.length) {
            return
        }
        notificationsModel.invokeAction(notificationsModel.index(0, 0), names[i])
        closePopup()
    }

    Timer {
        id: popupCloseTimer
        interval: 130
        onTriggered: popup.visible = false
    }

    function openPopup() {
        popupCloseTimer.stop()
        popup.visible = true
        popupOpen = true
    }

    function closePopup() {
        popupOpen = false
        popupCloseTimer.restart()
    }

    function togglePopup() {
        if (popupOpen) {
            closePopup()
        } else {
            openPopup()
        }
    }

    NotificationManager.Settings {
        id: notificationSettings
    }

    NotificationManager.Notifications {
        id: notificationsModel
        limit: 1
        showExpired: false
        showDismissed: false
        showNotifications: true
        showJobs: true
        sortMode: NotificationManager.Notifications.SortByDate
        sortOrder: Qt.DescendingOrder
        groupMode: NotificationManager.Notifications.GroupDisabled

        onUnreadNotificationsCountChanged: {
            root.unreadCount = unreadNotificationsCount
            if (unreadNotificationsCount > 0 && root.enableNotifications) {
                notificationPulse.restart()
            }
        }

        onActiveJobsCountChanged: {
            root.jobsCount = activeJobsCount
        }

        onJobsPercentageChanged: root.jobsPercent = jobsPercentage

        Component.onCompleted: {
            root.unreadCount = unreadNotificationsCount
            root.jobsCount = activeJobsCount
            root.jobsPercent = jobsPercentage
        }
    }

    Connections {
        target: NotificationManager.Server

        function onNotificationAdded(notification) {
            if (!root.enableNotifications) {
                return
            }
            root.notificationTitle = notification.summary || ""
            root.notificationBody = notification.body || notification.text || ""
            root.notificationApp = notification.applicationName || ""
            root.notificationIcon = notification.applicationIconName || notification.iconName || "notifications"
            if (root.notificationIcon.length === 0) {
                root.notificationIcon = "notifications"
            }
            root.notificationActionNames = notification.actionNames || []
            root.notificationActionLabels = notification.actionLabels || []
            root.notificationHasDefaultAction = notification.hasDefaultAction || false
            notificationPulse.restart()
        }
    }

    Repeater {
        model: notificationsModel

        Item {
            readonly property string summaryValue: model.summary || ""
            readonly property string bodyValue: model.body || ""
            readonly property string appValue: model.applicationName || ""
            readonly property string appIconValue: model.applicationIconName || ""
            readonly property string iconValue: model.iconName || ""
            readonly property var actionsValue: model.actionNames || []

            visible: false
            Component.onCompleted: root.setNotification(model)
            onSummaryValueChanged: root.setNotification(model)
            onBodyValueChanged: root.setNotification(model)
            onActionsValueChanged: root.setNotification(model)
        }
    }

    MouseArea {
        id: mouseArea

        anchors.fill: parent
        hoverEnabled: true
        acceptedButtons: Qt.LeftButton | Qt.MiddleButton
        onClicked: (mouse) => {
            if (mouse.button === Qt.MiddleButton) {
                if (root.hasNotification && root.unreadCount > 0) {
                    root.dismissNotification()
                }
                return
            }
            root.togglePopup()
        }
    }

    onCompactWidthChanged: if (animationsEnabled) islandPop.restart()

    Rectangle {
        id: island

        anchors.centerIn: parent
        width: root.compactWidth
        height: root.compactHeight
        radius: height / 2
        color: root.panelBackground
        border.width: root.borderEnabled && root.backgroundEnabled ? 1 : 0
        border.color: root.borderColor
        transformOrigin: Item.Center

        Behavior on color { ColorAnimation { duration: root.animationsEnabled ? Math.round(160 * root.animMultiplier) : 0 } }
        Behavior on opacity { NumberAnimation { duration: root.animationsEnabled ? Math.round(140 * root.animMultiplier) : 0; easing.type: Easing.OutCubic } }
        Behavior on width { NumberAnimation { duration: root.animationsEnabled ? Math.round(220 * root.animMultiplier) : 0; easing.type: Easing.OutCubic } }

        SequentialAnimation {
            id: islandPop

            NumberAnimation { target: island; property: "scale"; to: 1.06; duration: root.animationsEnabled ? Math.round(110 * root.animMultiplier) : 0; easing.type: Easing.OutCubic }
            NumberAnimation { target: island; property: "scale"; to: 1.0; duration: root.animationsEnabled ? Math.round(170 * root.animMultiplier) : 0; easing.type: Easing.OutBack }
        }

        Loader {
            id: compactLoader

            anchors.fill: parent
            sourceComponent: compactContent

            onLoaded: {
                item.opacity = 0
                item.scale = 0.96
                compactFade.target = item
                compactScale.target = item
                compactFade.restart()
                compactScale.restart()
            }
        }

        NumberAnimation {
            id: compactFade
            property: "opacity"
            to: 1
            duration: root.animationsEnabled ? Math.round(120 * root.animMultiplier) : 0
            easing.type: Easing.OutCubic
        }

        NumberAnimation {
            id: compactScale
            property: "scale"
            to: 1
            duration: root.animationsEnabled ? Math.round(160 * root.animMultiplier) : 0
            easing.type: Easing.OutCubic
        }
    }

    PlasmaCore.Dialog {
        id: popup

        visualParent: root
        location: Plasmoid.location
        visible: false
        x: Math.round((root.compactWidth - root.expandedWidth) / 2)
        y: root.compactHeight + Plasmoid.configuration.popupGap
        hideOnWindowDeactivate: true
        backgroundHints: PlasmaCore.Dialog.NoBackground

        Component.onCompleted: flags = flags | Qt.WindowStaysOnTopHint

        onVisibleChanged: {
            if (!visible) {
                popupCloseTimer.stop()
                root.popupOpen = false
            }
        }

        mainItem: Item {
            width: root.expandedWidth
            height: root.expandedHeight
            opacity: root.popupOpen ? 1 : 0
            scale: root.popupOpen ? 1 : 0.92

            Behavior on opacity { NumberAnimation { duration: root.animationsEnabled ? Math.round(130 * root.animMultiplier) : 0; easing.type: Easing.OutCubic } }
            Behavior on scale { NumberAnimation { duration: root.animationsEnabled ? Math.round(170 * root.animMultiplier) : 0; easing.type: Easing.OutBack } }

            MouseArea {
                id: popupMouseArea
                anchors.fill: parent
                hoverEnabled: true
                onExited: root.closePopup()
            }

            Rectangle {
                anchors.fill: parent
                radius: root.cornerRadius
                color: root.panelBackground
                border.width: root.borderEnabled && root.backgroundEnabled ? 1 : 0
                border.color: root.borderColor

                Loader {
                    id: expandedLoader
                    anchors.fill: parent
                    sourceComponent: expandedContent

                    onLoaded: {
                        item.opacity = 0
                        item.scale = 0.97
                        expandedFade.target = item
                        expandedScale.target = item
                        expandedFade.restart()
                        expandedScale.restart()
                    }
                }
            }
        }
    }

    NumberAnimation { id: expandedFade; property: "opacity"; to: 1; duration: 120; easing.type: Easing.OutCubic }
    NumberAnimation { id: expandedScale; property: "scale"; to: 1; duration: 160; easing.type: Easing.OutCubic }

    // ===================== COMPACT CONTENT =====================
    // All modules arranged horizontally: Time | CPU | RAM | Temp | FPS | Notification
    Component {
        id: compactContent

        RowLayout {
            id: compactLayout
            anchors.fill: parent
            anchors.leftMargin: root.compactSidePadding
            anchors.rightMargin: root.compactSidePadding
            spacing: root.moduleSeparators ? 10 : 12

            // ---- TIME BLOCK ----
            RowLayout {
                Layout.alignment: Qt.AlignVCenter
                spacing: 4

                PlasmaComponents.Label {
                    text: "/"
                    visible: root.moduleSeparators
                    color: Qt.rgba(1, 1, 1, 0.4)
                    font.pointSize: 15
                    Layout.alignment: Qt.AlignVCenter
                }

                // Time label with hover tooltip and click to open calendar
                Item {
                    Layout.alignment: Qt.AlignVCenter

                    TextMetrics {
                        id: timeTextMetrics
                        text: root.timeText
                        font.pointSize: 16
                        font.weight: Font.Medium
                    }

                    width: timeTextMetrics.width + 8
                    height: parent.height

                    PlasmaComponents.Label {
                        anchors.centerIn: parent
                        text: root.timeText
                        color: root.textPrimary
                        font.pointSize: 16
                        font.weight: Font.Medium
                    }

                    MouseArea {
                        anchors.fill: parent
                        hoverEnabled: true
                        acceptedButtons: Qt.LeftButton
                        onEntered: {
                            root.toolTipMainText = Tr.t("Click to open calendar")
                            root.toolTipSubText = Tr.t("Opens the Plasma desktop calendar")
                        }
                        onExited: {
                            root.toolTipMainText = ""
                            root.toolTipSubText = ""
                        }
                        onClicked: {
                            // Open Plasma calendar via D-Bus
                            dbusLauncher.launchCalendar()
                        }
                    }
                }
            }

            // ---- CPU BLOCK ----
            RowLayout {
                visible: root.showCpuStat
                Layout.alignment: Qt.AlignVCenter
                spacing: 4

                PlasmaComponents.Label {
                    text: "/"
                    visible: root.moduleSeparators
                    color: Qt.rgba(1, 1, 1, 0.4)
                    font.pointSize: 15
                    Layout.alignment: Qt.AlignVCenter
                }

                Item {
                    Layout.alignment: Qt.AlignVCenter

                    TextMetrics {
                        id: cpuTextMetrics
                        text: "CPU " + Math.round(root.cpuUsage) + "%"
                        font.pointSize: 12
                        font.weight: Font.Medium
                    }

                    width: cpuTextMetrics.width + 8
                    height: parent.height

                    PlasmaComponents.Label {
                        anchors.centerIn: parent
                        text: "CPU " + Math.round(root.cpuUsage) + "%"
                        color: root.textPrimary
                        font.pointSize: 12
                        font.weight: Font.Medium
                    }

                    MouseArea {
                        anchors.fill: parent
                        hoverEnabled: true
                        acceptedButtons: Qt.LeftButton
                        onEntered: {
                            root.toolTipMainText = Tr.t("Click to open Task Manager")
                            root.toolTipSubText = Tr.t("Opens xfce4-taskmanager")
                        }
                        onExited: {
                            root.toolTipMainText = ""
                            root.toolTipSubText = ""
                        }
                        onClicked: {
                            dbusLauncher.launchTaskManager()
                        }
                    }
                }
            }

            // ---- RAM BLOCK ----
            RowLayout {
                visible: root.showRamStat
                Layout.alignment: Qt.AlignVCenter
                spacing: 4

                PlasmaComponents.Label {
                    text: "/"
                    visible: root.moduleSeparators
                    color: Qt.rgba(1, 1, 1, 0.4)
                    font.pointSize: 15
                    Layout.alignment: Qt.AlignVCenter
                }

                PlasmaComponents.Label {
                    text: "RAM " + Math.round(root.ramUsage) + "%"
                    color: root.textPrimary
                    font.pointSize: 12
                    font.weight: Font.Medium
                    Layout.alignment: Qt.AlignVCenter
                }
            }

            // ---- TEMP BLOCK ----
            RowLayout {
                visible: root.showTempStat && root.cpuTemp > 0
                Layout.alignment: Qt.AlignVCenter
                spacing: 4

                PlasmaComponents.Label {
                    text: "/"
                    visible: root.moduleSeparators
                    color: Qt.rgba(1, 1, 1, 0.4)
                    font.pointSize: 15
                    Layout.alignment: Qt.AlignVCenter
                }

                PlasmaComponents.Label {
                    text: Math.round(root.cpuTemp) + "°C"
                    color: root.textPrimary
                    font.pointSize: 12
                    font.weight: Font.Medium
                    Layout.alignment: Qt.AlignVCenter
                }
            }

            // ---- FPS BLOCK ----
            RowLayout {
                visible: root.showFps
                Layout.alignment: Qt.AlignVCenter
                spacing: 4

                PlasmaComponents.Label {
                    text: "/"
                    visible: root.moduleSeparators
                    color: Qt.rgba(1, 1, 1, 0.4)
                    font.pointSize: 15
                    Layout.alignment: Qt.AlignVCenter
                }

                PlasmaComponents.Label {
                    text: root.fps + " fps"
                    color: root.fpsStyle === "plain" ? root.textPrimary : root.accent
                    font.pointSize: root.fpsStyle === "plain" ? 14 : 9
                    font.weight: root.fpsStyle === "plain" ? Font.Medium : Font.Bold
                    Layout.alignment: Qt.AlignVCenter
                }
            }

            // ---- NOTIFICATION BLOCK ----
            RowLayout {
                visible: root.hasNotification
                Layout.alignment: Qt.AlignVCenter
                spacing: 4

                PlasmaComponents.Label {
                    text: "/"
                    visible: root.moduleSeparators
                    color: Qt.rgba(1, 1, 1, 0.4)
                    font.pointSize: 15
                    Layout.alignment: Qt.AlignVCenter
                }

                StatusIcon {
                    mode: 2
                    iconName: root.notificationIcon
                    unread: root.unreadCount
                    Layout.preferredWidth: 24
                    Layout.preferredHeight: 24
                }

                PlasmaComponents.Label {
                    text: root.compactTitle
                    visible: text.length > 0
                    color: root.textPrimary
                    font.pointSize: 12
                    font.weight: Font.Medium
                    elide: Text.ElideRight
                    Layout.maximumWidth: root.compactTextMaxWidth
                }

                Rectangle {
                    id: unreadBadge
                    visible: root.unreadCount > 0
                    Layout.preferredWidth: 22
                    Layout.preferredHeight: 22
                    radius: 6
                    color: root.accent

                    SequentialAnimation on scale {
                        running: unreadBadge.visible && notificationPulse.running && root.animationsEnabled
                        loops: Animation.Infinite
                        NumberAnimation { to: 1.18; duration: root.dur(520); easing.type: Easing.OutCubic }
                        NumberAnimation { to: 1.0; duration: root.dur(520); easing.type: Easing.InCubic }
                    }

                    PlasmaComponents.Label {
                        anchors.centerIn: parent
                        text: root.unreadCount
                        color: "white"
                        font.bold: true
                    }
                }
            }

            // Spacer to fill remaining width
            Item {
                Layout.fillWidth: true
            }
        }
    }

    // ===================== EXPANDED CONTENT =====================
    Component {
        id: expandedContent

        Item {
            anchors.fill: parent

            // Status / Notification expanded panel
            Item {
                anchors.fill: parent

                StatusIcon {
                    id: expandedIcon
                    anchors.left: parent.left
                    anchors.leftMargin: 16
                    anchors.verticalCenter: parent.verticalCenter
                    width: 44
                    height: 44
                    mode: root.hasNotification ? 2 : 0
                    iconName: root.notificationIcon
                    unread: root.unreadCount
                }

                Column {
                    anchors.left: expandedIcon.right
                    anchors.leftMargin: 14
                    anchors.right: parent.right
                    anchors.rightMargin: 16
                    anchors.verticalCenter: parent.verticalCenter
                    spacing: 5

                    PlasmaComponents.Label {
                        width: parent.width
                        text: root.hasNotification ? (root.notificationTitle || Tr.t("Notification")) : Tr.t("System Status")
                        color: root.textPrimary
                        font.pointSize: 13
                        font.weight: Font.Medium
                        elide: Text.ElideRight
                    }

                    PlasmaComponents.Label {
                        width: parent.width
                        text: root.hasNotification
                            ? (root.notificationBody || root.notificationApp || (root.unreadCount > 0 ? Tr.tr("%1 unread", root.unreadCount) : Tr.t("New notification")))
                            : (root.showCpuStat ? "CPU " + Math.round(root.cpuUsage) + "%  " : "") +
                              (root.showRamStat ? "RAM " + Math.round(root.ramUsage) + "%  " : "") +
                              (root.showTempStat && root.cpuTemp > 0 ? Math.round(root.cpuTemp) + "°C" : "")
                        color: root.textSecondary
                        font.pointSize: 10
                        wrapMode: Text.WordWrap
                        maximumLineCount: Plasmoid.configuration.notificationBodyLines
                        elide: Text.ElideRight
                    }
                }
            }
        }
    }

    // ===================== LAUNCHER HELPERS =====================
    // Helper for launching external applications.
    // Uses D-Bus (org.freedesktop.portal.Desktop) as primary method,
    // with QProcess fallback for environments where the portal is unavailable.

    QtObject {
        id: dbusLauncher

        // ---- Open Plasma Desktop Calendar ----
        // Opens the KDE Plasma calendar via D-Bus.
        // Tries multiple methods in order of preference.
        function launchCalendar() {
            // Method 1: Use org.freedesktop.portal.Desktop to launch kalendar
            try {
                var portal = Qt.createQmlObject('
                    import QtQuick 2.15
                    import QtDBus 5.15
                    Item {
                        DBusInterface {
                            id: portalIface
                            service: "org.freedesktop.portal.Desktop"
                            path: "/org/freedesktop/portal/desktop"
                            iface: "org.freedesktop.portal.OpenURI"
                        }
                        function openCalendar() {
                            // Launch the KDE calendar application
                            portalIface.call("OpenFile", ["", "file:///usr/bin/kalendar", {}])
                        }
                    }
                ', root)
                if (portal) {
                    portal.openCalendar()
                    return
                }
            } catch(e) {
                console.log("Portal method failed:", e)
            }

            // Method 2: Direct D-Bus call to start kalendar or kclock
            try {
                var dbus = Qt.createQmlObject('
                    import QtQuick 2.15
                    import QtDBus 5.15
                    Item {
                        DBusInterface {
                            id: launcher
                            service: "org.kde.klauncher5"
                            path: "/KLauncher"
                            iface: "org.kde.KLauncher"
                        }
                        function launch(cmd) {
                            launcher.call("exec_blind", [cmd])
                        }
                    }
                ', root)
                if (dbus) {
                    // Try kalendar first, then kclock
                    dbus.launch("kalendar")
                    return
                }
            } catch(e) {
                console.log("KLauncher method failed:", e)
            }

            // Fallback: Use Qt.openUrlExternally which delegates to the shell
            Qt.openUrlExternally("calendar://")
        }

        // ---- Open Task Manager ----
        // Launches /usr/bin/xfce4-taskmanager
        function launchTaskManager() {
            // Primary: D-Bus KLauncher
            try {
                var dbus = Qt.createQmlObject('
                    import QtQuick 2.15
                    import QtDBus 5.15
                    Item {
                        DBusInterface {
                            id: launcher
                            service: "org.kde.klauncher5"
                            path: "/KLauncher"
                            iface: "org.kde.KLauncher"
                        }
                        function launch(cmd) {
                            launcher.call("exec_blind", [cmd])
                        }
                    }
                ', root)
                if (dbus) {
                    dbus.launch("/usr/bin/xfce4-taskmanager")
                    return
                }
            } catch(e) {
                console.log("D-Bus launch failed:", e)
            }

            // Fallback: Qt.openUrlExternally
            Qt.openUrlExternally("file:///usr/bin/xfce4-taskmanager")
        }
    }

    // ===================== COMPONENTS =====================
    component StatusIcon: Item {
        property int mode: 0
        property int unread: 0
        property string iconName: "notifications"

        Rectangle {
            anchors.fill: parent
            radius: width / 2
            color: mode === 2 ? "#2da6e8" : Qt.rgba(0.55, 0.4, 1, 0.3)
            Behavior on color { ColorAnimation { duration: root.dur(160) } }
        }

        Kirigami.Icon {
            anchors.centerIn: parent
            width: parent.width * 0.62
            height: width
            source: mode === 2 ? iconName : "utilities-terminal"
        }
    }
}
